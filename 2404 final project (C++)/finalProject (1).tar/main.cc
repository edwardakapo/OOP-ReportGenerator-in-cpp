#include "Control.h"

int main()
{
  Control menu;
  menu.launch();

  return 0;
}
