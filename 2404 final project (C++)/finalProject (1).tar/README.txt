Author: Oluwademilade Edward Akapo
Student No: 101095403

Purpose:  To write a program that generates a set of reports based on data recieved from a file.

Files:
CompareBehaviour.cc              , CompareBehaviour.h            , Map.h
Control.cc                       , PercentageBreakDownReport.cc  , Control.h
farms.dat                        , Record.cc                     , ReportGenerator.cc
HorsesAndPoniesByRegionReport.cc , Record.h                      , ReportGenerator.h
HorsesAndPoniesByRegionReport.h  , RegionalBreakdownReport.cc    , View.cc
main.cc                          , RegionalBreakdownReport.h     , View.h
PercentageBreakDownReport.h      , ReportData.h



Compiling and Launching: To compile type "make" to launch type "./fp"
